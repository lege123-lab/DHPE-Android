package et.dhpe.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFFF5F8FC.toInt())
        }

        val title = TextView(this).apply {
            text = "ዲጂታል የጤና ኬላ"
            textSize = 25f
            setTextColor(0xFF123B63.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Digital Health Post Ethiopia (DHPE)\nየመጀመሪያ የሙከራ ስሪት"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 24)
            setTextColor(0xFF536579.toInt())
        }
        root.addView(subtitle)

        val status = TextView(this).apply {
            text = "የጤና ኬላ ዋና አገልግሎቶች"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF1B344D.toInt())
            setPadding(0, 0, 0, 12)
        }
        root.addView(status)

        val items = listOf(
            "👤  የታካሚ ምዝገባ",
            "🤱  የእናቶችና ሕፃናት ክትትል",
            "💊  የመድኃኒት ክምችት",
            "🧪  የላቦራቶሪ መዝገብ",
            "↗  የሪፈራል አገልግሎት",
            "📊  ሪፖርቶች"
        )

        items.forEach { label ->
            val button = Button(this).apply {
                text = label
                textSize = 16f
                isAllCaps = false
                setOnClickListener {
                    Toast.makeText(this@MainActivity,
                        "ይህ ክፍል በቀጣይ ይገነባል።", Toast.LENGTH_SHORT).show()
                }
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 5, 0, 5)
            root.addView(button, params)
        }

        val note = TextView(this).apply {
            text = "ማስታወሻ፦ ይህ የማሳያ ስሪት ነው። እውነተኛ የታካሚ መረጃ አያስቀምጥም።"
            textSize = 12f
            setTextColor(0xFF9A4B22.toInt())
            setPadding(0, 20, 0, 0)
        }
        root.addView(note)

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
